"""Fonte única dos itens do orçamento (consulta em 30/10/2026).

Status do preço:
  PESQ  = pesquisado na página do produto (preço e dados técnicos conferidos)
  LIST  = pesquisado na listagem/busca da loja (preço conferido; ficha técnica não aberta)
  EST   = estimativa (sem cotação; faixa de mercado citada na coluna "fonte")
Preços Pichau = à vista no PIX; Amazon = preço exibido no anúncio. Preços mudam: reconfirmar antes de comprar.
"""

DATA = "30/10/2026"
AMZ = "https://www.amazon.com.br/dp/"
PCH = "https://www.pichau.com.br/"

FONTE_RIPADO = ("Faixa R$ 250–600/m² instalado (Revista Oeste); R$ 180–750/m² (Monitor do Mercado) — "
                "https://monitordomercado.com.br/economia-2/385193-quanto-custa-instalar-painel-ripado-e-transformar-a-sala-com-um-visual-moderno-e-sofisticado/")
FONTE_PINTOR = ("Faixa R$ 15–35/m² simples; R$ 35–60/m² com preparo (Lar Pontual) — "
                "https://larpontual.com.br/portal/preco-de-pintor-por-m2")

# Cada item: (categoria, item, produto, loja, link, dimensões, material, status, qtd, preço_unit, unidade)
# qtd pode ser uma string "Q:<nome>" que aponta para a aba Quantitativos (fórmula no XLSX).
CAT = ["Mobiliário", "Marcenaria", "Iluminação", "Pintura", "Complementares", "Decoração (opcional)", "Serviços"]

def _mesa_pichau():
    return ("Mobiliário", "Mesa regulável elétrica", "Pichau Starlift Pro 160×70 (1 motor, 80 kg, tampo MDP 15 mm)",
            "Pichau", PCH + "mesa-pichau-starlift-pro-com-regulagem-de-altura-160x80cm-preto",
            "160 × 70 × 73–118", "Aço + MDP melamina preto", "PESQ", 1, 823.99, "un")

ECONOMICO = [
    _mesa_pichau(),
    ("Mobiliário", "Placa de reforço p/ braço (tampo de 15 mm)", "Placa de reforço de montagem de monitor (aço)", "Amazon",
     AMZ + "B0FSXG2BJ5", "—", "Aço", "LIST", 1, 161.40, "un"),
    ("Mobiliário", "Cadeira ergonômica", "DT3 Worka Preto 14961-1", "Pichau",
     PCH + "cadeira-ergonomica-dt3-worka-preto-14961-1", "não declarada (est. 65 × 65)", "Tela/nylon", "LIST", 1, 749.99, "un"),
    ("Mobiliário", "Cama box + colchão solteiro", "Cama Box Solteiro Colchão Molas Qatar", "Amazon",
     AMZ + "B0C4648NG8", "88 × 188 × 60", "Molas + base box", "LIST", 1, 630.83, "un"),
    ("Mobiliário", "Braço articulado 2 monitores", "Braço duplo pistão a gás 13–27\" (2–9 kg) — NÃO serve ultrawide 34\"",
     "Amazon", AMZ + "B0H6NHQXHW", "—", "Aço/alumínio", "LIST", 1, 157.69, "un"),
    ("Marcenaria", "Painel ripado Parede D (piso→teto)", "Ripado MDF BP amadeirado sobre fundo preto, instalado", "Marceneiro local",
     FONTE_RIPADO, "265 × 3 × 264", "MDF BP", "EST", "Q:area_ripado", 250.00, "m²"),
    ("Marcenaria", "Prateleiras sobre a mesa", "Prateleira MDF Freijó 80×25 c/ suporte invisível (kit 2)", "Amazon",
     AMZ + "B0HPF7JM1G", "2 × (80 × 25)", "MDF freijó", "LIST", 1, 436.00, "kit"),
    ("Marcenaria", "Nichos iluminados 3× (cabeceira)", "MDF BP freijó 15 mm, fundo preto, rasgo p/ LED", "Marceneiro local",
     "Estimativa", "3 × (24 × 26 × 16)", "MDF BP freijó", "EST", 1, 300.00, "vb"),
    ("Iluminação", "Fita LED COB 3000 K", "Fita LED COB 24V 15W/m 480 LEDs 3000K 5 m", "Amazon", AMZ + "B0GBY67PN3",
     "5 m", "—", "LIST", "Q:rolos_led", 74.95, "rolo"),
    ("Iluminação", "Fonte 24 V", "Fonte chaveada slim 24V 5A 120W bivolt", "Amazon", AMZ + "B0H7CQ2BY2", "—", "—", "LIST", 1, 61.99, "un"),
    ("Iluminação", "Perfil de alumínio p/ LED", "Perfil LED embutir 24×7 mm slim 2 m preto", "Amazon", AMZ + "B0F1ZBZZTP",
     "200 cm", "Alumínio", "LIST", "Q:barras_perfil", 29.90, "barra"),
    ("Iluminação", "Dimmer da fita", "Controle remoto IR c/ dimmer 12/24V", "Amazon", AMZ + "B0FJH6572V", "—", "—", "LIST", 1, 31.50, "un"),
    ("Iluminação", "Barra de luz p/ monitor", "Luminária p/ monitor 3 temperaturas, toque", "Amazon", AMZ + "B0GXZ9CN8M", "—", "—", "LIST", 1, 56.99, "un"),
    ("Iluminação", "Arandela da cama", "Arandela tubo articulada preta c/ interruptor (conferir se tem plugue)", "Amazon",
     AMZ + "B0DND64VLW", "—", "Metal", "LIST", 1, 74.95, "un"),
    ("Iluminação", "Lâmpadas 3000 K (ventilador/teto)", "LEDVANCE OSRAM CLA60 9W 3000K E27 (kit 10)", "Amazon",
     AMZ + "B0HNY3SPM6", "—", "—", "LIST", 1, 69.90, "kit"),
    ("Pintura", "Tinta paredes (grafite)", "Coral Coralar acrílica 3,6 L — preço da base; cor grafite preparada em loja (conferir)",
     "Amazon", AMZ + "B0G62TWLCN", "3,6 L", "Acrílica fosca", "LIST", "Q:galoes_parede", 61.74, "galão"),
    ("Pintura", "Tinta teto (branco)", "Coral Coralar acrílica Branco 3,6 L", "Amazon", AMZ + "B0G62TCBGG", "3,6 L", "Acrílica",
     "LIST", "Q:galoes_teto", 61.74, "galão"),
    ("Pintura", "Kit pintura", "Kit anti-gotas rolos 23/9 cm, bandeja, suporte e trincha", "Amazon", AMZ + "B0H6CMVSRL", "—", "—", "LIST", 1, 31.99, "kit"),
    ("Pintura", "Fita crepe", "Kit 2 fitas crepe 48 mm × 50 m", "Amazon", AMZ + "B0H8BCLC4J", "—", "—", "LIST", 1, 29.80, "kit"),
    ("Pintura", "Proteção de piso/móveis", "Lona protetora c/ fita 1,5 × 10 m", "Amazon", AMZ + "B0GVPX4YVY", "—", "—", "LIST", 1, 15.90, "un"),
    ("Pintura", "Massa/reparos pontuais", "Massa corrida + lixa (reparos)", "—", "Estimativa", "—", "—", "EST", 1, 60.00, "vb"),
    ("Complementares", "Tapete", "Tapete pelo baixo c/ relevo cinza escuro 2,00 × 1,40", "Amazon", AMZ + "B0GXCDQG6W",
     "140 × 200", "Sintético", "LIST", 1, 142.40, "un"),
    ("Complementares", "Filtro de linha c/ DPS", "iCLAMPER Energia 5 tomadas", "Amazon", AMZ + "B0D8V17JSG", "—", "—", "LIST", 1, 71.98, "un"),
    ("Complementares", "Prolongador da tomada (ripado)", "Margirius prolongador caixa 4×2", "Amazon", AMZ + "B089M44PPG", "—", "—", "LIST", 1, 23.27, "un"),
    ("Complementares", "Organização de cabos", "Organizador de fios 19 mm × 1,5 m", "Amazon", AMZ + "B08R58CWKD", "—", "—", "LIST", 1, 16.17, "un"),
    ("Complementares", "Abraçadeiras", "Abraçadeira nylon preta 2,5 × 100 mm (100 un)", "Amazon", AMZ + "B0GWNHFSCY", "—", "—", "LIST", 1, 10.20, "pct"),
    ("Complementares", "Suporte de notebook", "Suporte dobrável alumínio c/ regulagem", "Amazon", AMZ + "B0H13G1VTW", "—", "Alumínio", "LIST", 1, 65.78, "un"),
    ("Serviços", "Mão de obra de pintura", "Pintor (paredes + teto), sem preparo pesado", "Profissional local", FONTE_PINTOR,
     "—", "—", "EST", "Q:area_pintura_total", 25.00, "m²"),
    ("Serviços", "Frete (itens sem frete grátis)", "Reserva de frete", "—", "Estimativa", "—", "—", "EST", 1, 150.00, "vb"),
]

EQUILIBRADO = [
    _mesa_pichau()[:2] + ("Pichau Starlift Pro 160×70 — usar a ESTRUTURA (80 kg); o tampo original sobra",) + _mesa_pichau()[3:],
    ("Mobiliário", "Tampo sob medida", "Tampo MDF 25 mm freijó 170×70, borda reta, furo p/ braço e passa-cabo", "Marceneiro local",
     "Estimativa", "170 × 70 × 2,5", "MDF BP freijó", "EST", 1, 700.00, "un"),
    ("Mobiliário", "Cadeira ergonômica", "DT3 Elin Black 14881-2 (braço 5D, encosto de cabeça 3D, lombar)", "Pichau",
     PCH + "cadeira-ergonomica-dt3-elin-black-14881-2", "não declarada (est. 65 × 65)", "Tecido + nylon", "PESQ", 1, 1199.99, "un"),
    ("Mobiliário", "Cama box + colchão solteiro", "Gazin Maximus molas ensacadas, linho grafite/preto", "Amazon",
     AMZ + "B0D1J7X17Z", "88 × 188 × 62", "Molas ensacadas", "LIST", 1, 899.10, "un"),
    ("Mobiliário", "Braço articulado 2 monitores", "ELG F160N 17–35\" (2–9 kg/braço; borda ou furo)", "Amazon",
     AMZ + "B0765KZDWP", "—", "Aço/alumínio", "PESQ", 1, 218.87, "un"),
    ("Marcenaria", "Painel ripado Parede D (piso→teto)", "Ripado MDF BP freijó + fundo preto, recortes, instalado", "Marceneiro local",
     FONTE_RIPADO, "265 × 3 × 264", "MDF BP freijó", "EST", "Q:area_ripado", 400.00, "m²"),
    ("Marcenaria", "Prateleira sobre a mesa", "Prateleira freijó 170×25 c/ rasgo para LED, h = 1,95 m", "Marceneiro local",
     "Estimativa", "170 × 25 × 2,5", "MDF BP freijó", "EST", 1, 500.00, "un"),
    ("Marcenaria", "Nichos iluminados 3× (cabeceira)", "MDF BP freijó 15 mm, fundo preto, rasgo p/ LED", "Marceneiro local",
     "Estimativa", "3 × (24 × 26 × 16)", "MDF BP freijó", "EST", 1, 450.00, "vb"),
    ("Iluminação", "Fita LED COB 3000 K", "Stella All Light Pro 16W/m 24V COB 3000K IRC 95+ 5 m", "Amazon", AMZ + "B0F7ZGD3M2",
     "5 m", "—", "LIST", "Q:rolos_led", 200.69, "rolo"),
    ("Iluminação", "Fonte 24 V", "Fonte chaveada slim 24V 5A 120W bivolt", "Amazon", AMZ + "B0H7CQ2BY2", "—", "—", "LIST", 1, 61.99, "un"),
    ("Iluminação", "Perfil de alumínio p/ LED", "Perfil LED embutir 24×7 mm slim 2 m preto", "Amazon", AMZ + "B0F1ZBZZTP",
     "200 cm", "Alumínio", "LIST", "Q:barras_perfil", 29.90, "barra"),
    ("Iluminação", "Controle Wi-Fi da fita", "Controlador Wi-Fi c/ dimmer (Alexa/Google)", "Amazon", AMZ + "B0FS91PKKL", "—", "—", "LIST", 1, 43.02, "un"),
    ("Iluminação", "Barra de luz p/ monitor", "Quntis Light Bar PRO+ c/ controle remoto", "Amazon", AMZ + "B0B6P9J3J5", "—", "—", "LIST", 1, 293.55, "un"),
    ("Iluminação", "Arandela da cama", "Arandela tubo articulada preta c/ interruptor (conferir se tem plugue)", "Amazon",
     AMZ + "B0DND64VLW", "—", "Metal", "LIST", 1, 74.95, "un"),
    ("Iluminação", "Lâmpadas 3000 K (ventilador/teto)", "LEDVANCE OSRAM CLA60 9W 3000K E27 (kit 10)", "Amazon",
     AMZ + "B0HNY3SPM6", "—", "—", "LIST", 1, 69.90, "kit"),
    ("Pintura", "Tinta paredes (grafite)", "Suvinil Fosco Completo 3,6 L — preço da base branca; cor grafite em loja (conferir)",
     "Amazon", AMZ + "B077G771GN", "3,6 L", "Acrílica fosca", "LIST", "Q:galoes_parede", 179.90, "galão"),
    ("Pintura", "Tinta teto (branco)", "Suvinil acrílica fosca para teto Branco Neve 3,6 L", "Amazon", AMZ + "B077G6GQSP",
     "3,6 L", "Acrílica", "LIST", "Q:galoes_teto", 171.00, "galão"),
    ("Pintura", "Kit pintura", "Kit anti-gotas rolos 23/9 cm, bandeja, suporte e trincha", "Amazon", AMZ + "B0H6CMVSRL", "—", "—", "LIST", 1, 31.99, "kit"),
    ("Pintura", "Fita crepe", "Kit 2 fitas crepe 48 mm × 50 m", "Amazon", AMZ + "B0H8BCLC4J", "—", "—", "LIST", 1, 29.80, "kit"),
    ("Pintura", "Proteção de piso/móveis", "Lona protetora c/ fita 1,5 × 10 m", "Amazon", AMZ + "B0GVPX4YVY", "—", "—", "LIST", 1, 15.90, "un"),
    ("Pintura", "Massa/reparos pontuais", "Massa corrida + lixa (reparos)", "—", "Estimativa", "—", "—", "EST", 1, 60.00, "vb"),
    ("Complementares", "Tapete", "Tapete pelo baixo c/ relevo cinza escuro 2,00 × 1,40", "Amazon", AMZ + "B0GXCDQG6W",
     "140 × 200", "Sintético", "LIST", 1, 142.40, "un"),
    ("Complementares", "Filtro de linha c/ DPS", "iCLAMPER Energia 5 tomadas", "Amazon", AMZ + "B0D8V17JSG", "—", "—", "LIST", 1, 71.98, "un"),
    ("Complementares", "Prolongador da tomada (ripado)", "Margirius prolongador caixa 4×2", "Amazon", AMZ + "B089M44PPG", "—", "—", "LIST", 1, 23.27, "un"),
    ("Complementares", "Bandeja de cabos sob a mesa", "Bandeja organizadora sem perfuração", "Amazon", AMZ + "B0GJRDZM82", "—", "Metal", "LIST", 1, 119.69, "un"),
    ("Complementares", "Suporte de notebook", "Suporte dobrável alumínio c/ regulagem", "Amazon", AMZ + "B0H13G1VTW", "—", "Alumínio", "LIST", 1, 65.78, "un"),
    ("Serviços", "Mão de obra de pintura", "Pintor c/ preparo (paredes + teto)", "Profissional local", FONTE_PINTOR,
     "—", "—", "EST", "Q:area_pintura_total", 35.00, "m²"),
    ("Serviços", "Instalação da iluminação", "Montagem das fitas/perfis/fonte (marceneiro ou eletricista)", "Profissional local",
     "Estimativa", "—", "—", "EST", 1, 250.00, "vb"),
    ("Serviços", "Frete (itens sem frete grátis)", "Reserva de frete", "—", "Estimativa", "—", "—", "EST", 1, 200.00, "vb"),
]

PREMIUM = [
    ("Mobiliário", "Estrutura elétrica motor duplo", "Marsail motor duplo 120 kg, 71–118 cm, preta (Amazon Global — importação)",
     "Amazon", AMZ + "B0H45N1KWD", "tampos até 230 × 101", "Aço", "PESQ", 1, 2020.64, "un"),
    ("Mobiliário", "Tampo sob medida", "Tampo 30 mm lâmina natural freijó 170×70, borda maciça, furo p/ braço", "Marceneiro local",
     "Estimativa", "170 × 70 × 3", "MDF + lâmina natural", "EST", 1, 1100.00, "un"),
    ("Mobiliário", "Cadeira ergonômica", "DT3 Ergonomie Preto 14435-7", "Pichau", PCH + "cadeira-ergonomica-dt3-ergonomie-preto-14435-7",
     "não declarada (est. 70 × 70)", "Tela", "LIST", 1, 2599.99, "un"),
    ("Mobiliário", "Cama box baú + colchão solteiro", "Inducol Real molas ensacadas, box baú (armazenamento)", "Amazon",
     AMZ + "B0D54VM511", "88 × 188 × 68", "Molas ensacadas", "LIST", 1, 1169.10, "un"),
    ("Mobiliário", "Braço articulado 2 monitores", "ELG F196dp 17–35\" grafite, c/ cabo DisplayPort", "Amazon",
     AMZ + "B0HKLNT1LN", "—", "Aço/alumínio", "LIST", 1, 284.99, "un"),
    ("Marcenaria", "Painel ripado Parede D (piso→teto)", "Ripado em lâmina natural freijó + fundo preto, instalado", "Marceneiro local",
     FONTE_RIPADO, "265 × 3 × 264", "Lâmina natural", "EST", "Q:area_ripado", 600.00, "m²"),
    ("Marcenaria", "Prateleira sobre a mesa", "Prateleira lâmina natural 170×25 c/ LED embutido, h = 1,95 m", "Marceneiro local",
     "Estimativa", "170 × 25 × 3", "Lâmina natural", "EST", 1, 800.00, "un"),
    ("Marcenaria", "Nichos iluminados 3× (cabeceira)", "Lâmina natural freijó, fundo preto, LED embutido", "Marceneiro local",
     "Estimativa", "3 × (24 × 26 × 16)", "Lâmina natural", "EST", 1, 700.00, "vb"),
    ("Iluminação", "Fita LED COB 3000 K", "Stella All Light Pro 16W/m 24V COB 3000K IRC 95+ 5 m", "Amazon", AMZ + "B0F7ZGD3M2",
     "5 m", "—", "LIST", "Q:rolos_led_prem", 200.69, "rolo"),
    ("Iluminação", "Fonte 24 V", "Fonte chaveada slim 24V 5A 120W bivolt", "Amazon", AMZ + "B0H7CQ2BY2", "—", "—", "LIST", 2, 61.99, "un"),
    ("Iluminação", "Perfil de alumínio p/ LED", "Perfil LED embutir 24×7 mm slim 2 m preto", "Amazon", AMZ + "B0F1ZBZZTP",
     "200 cm", "Alumínio", "LIST", "Q:barras_perfil_prem", 29.90, "barra"),
    ("Iluminação", "Controle Wi-Fi da fita", "Controlador Wi-Fi c/ dimmer (Alexa/Google)", "Amazon", AMZ + "B0FS91PKKL", "—", "—", "LIST", 2, 43.02, "un"),
    ("Iluminação", "Barra de luz p/ monitor", "BenQ ScreenBar Pro (sensor de presença)", "Amazon", AMZ + "B0CZ9P1QW9", "—", "—", "LIST", 1, 1389.20, "un"),
    ("Iluminação", "Arandela da cama", "GOODATE arandela plug-in c/ interruptor regulável, braço oscilante", "Amazon",
     AMZ + "B094QSBVNB", "—", "Metal", "LIST", 1, 344.79, "un"),
    ("Iluminação", "Lâmpadas 3000 K (ventilador/teto)", "LEDVANCE OSRAM CLA60 9W 3000K E27 (kit 10)", "Amazon",
     AMZ + "B0HNY3SPM6", "—", "—", "LIST", 1, 69.90, "kit"),
    ("Pintura", "Tinta paredes (grafite)", "Suvinil Toque de Seda acetinado 3,6 L — preço da base branca; cor em loja (conferir)",
     "Amazon", AMZ + "B077G8JCN6", "3,6 L", "Acrílica acetinada", "LIST", "Q:galoes_parede", 206.10, "galão"),
    ("Pintura", "Tinta teto (branco)", "Suvinil acrílica fosca para teto Branco Neve 3,6 L", "Amazon", AMZ + "B077G6GQSP",
     "3,6 L", "Acrílica", "LIST", "Q:galoes_teto", 171.00, "galão"),
    ("Pintura", "Selador acrílico", "Selador acrílico 3,6 L", "Amazon", AMZ + "B0HCR49N2B", "3,6 L", "—", "LIST", 1, 40.40, "galão"),
    ("Pintura", "Kit pintura", "Kit anti-gotas rolos 23/9 cm, bandeja, suporte e trincha", "Amazon", AMZ + "B0H6CMVSRL", "—", "—", "LIST", 1, 31.99, "kit"),
    ("Pintura", "Fita crepe", "Kit 2 fitas crepe 48 mm × 50 m", "Amazon", AMZ + "B0H8BCLC4J", "—", "—", "LIST", 1, 29.80, "kit"),
    ("Pintura", "Proteção de piso/móveis", "Lona protetora c/ fita 1,5 × 10 m", "Amazon", AMZ + "B0GVPX4YVY", "—", "—", "LIST", 1, 15.90, "un"),
    ("Pintura", "Massa/reparos", "Massa corrida + lixa", "—", "Estimativa", "—", "—", "EST", 1, 90.00, "vb"),
    ("Complementares", "Tapete", "Tapete pelo baixo c/ relevo cinza escuro 2,00 × 1,40", "Amazon", AMZ + "B0GXCDQG6W",
     "140 × 200", "Sintético", "LIST", 1, 142.40, "un"),
    ("Complementares", "Filtro de linha c/ DPS", "iCLAMPER Energia 5 tomadas", "Amazon", AMZ + "B0D8V17JSG", "—", "—", "LIST", 1, 71.98, "un"),
    ("Complementares", "Prolongador da tomada (ripado)", "Margirius prolongador caixa 4×2", "Amazon", AMZ + "B089M44PPG", "—", "—", "LIST", 1, 23.27, "un"),
    ("Complementares", "Suporte de notebook", "Suporte aço carbono base giratória 360°", "Amazon", AMZ + "B0HFNYSZHZ", "—", "Aço", "LIST", 1, 109.15, "un"),
    ("Serviços", "Mão de obra de pintura", "Pintor c/ preparo completo (paredes + teto)", "Profissional local", FONTE_PINTOR,
     "—", "—", "EST", "Q:area_pintura_total", 55.00, "m²"),
    ("Serviços", "Instalação da iluminação", "Montagem das fitas/perfis/fontes (marceneiro ou eletricista)", "Profissional local",
     "Estimativa", "—", "—", "EST", 1, 400.00, "vb"),
    ("Serviços", "Frete e taxas de importação", "Reserva (Amazon Global pode ter impostos)", "—", "Estimativa", "—", "—", "EST", 1, 450.00, "vb"),
]

# Decoração (opcional): pacote do tema aprovado (Moderno Escuro), pesquisado em 31/10/2026 — mesmo nos 3 cenários.
import sys as _sys
from pathlib import Path as _Path
_sys.path.insert(0, str(_Path(__file__).resolve().parents[2] / "05_BLENDER" / "scripts"))
from temas_dados import PRECOS as _PRECOS, pacote as _pacote  # noqa: E402

DECORACAO = [("Decoração (opcional)", _PRECOS[k][0], _PRECOS[k][1], _PRECOS[k][2], _PRECOS[k][3] or "Estimativa", "—", "—",
              _PRECOS[k][5], q, _PRECOS[k][4], "un") for k, q in _pacote("escuro")[0]]
DECORACAO += [
    ("Decoração (opcional)", "Suporte de headphone", "Suporte de mesa em metal preto", "A pesquisar", "Estimativa", "—", "—",
     "EST", 1, 60.00, "un"),
    ("Decoração (opcional)", "Relógio LED de prateleira", "Relógio digital LED 12 cm", "A pesquisar", "Estimativa", "—", "—",
     "EST", 1, 70.00, "un"),
]
for _lista in (ECONOMICO, EQUILIBRADO, PREMIUM):
    _i = next(i for i, it in enumerate(_lista) if it[0] == "Serviços")
    _lista[_i:_i] = DECORACAO

CENARIOS = {"Econômico": ECONOMICO, "Equilibrado": EQUILIBRADO, "Premium": PREMIUM}

# Quantitativos (nome, descrição, valor ou fórmula Excel em função de outros nomes, unidade, status)
QUANT = [
    ("pe_direito", "Pé-direito", 2.64, "m", "Confirmada"),
    ("parede_e_comp", "Parede E — comprimento", 2.85, "m", "Confirmada"),
    ("janela_l", "Janela — largura", 1.45, "m", "Calculada"),
    ("janela_h", "Janela — altura", 1.20, "m", "Confirmada*"),
    ("parede_c_comp", "Parede C — comprimento", 2.00, "m", "Confirmada"),
    ("bwc_trechos", "Parede do banheiro voltada à faixa (sem o vão da porta)", 1.12, "m", "Calculada"),
    ("porta_bwc_l", "Porta do banheiro c/ batente", 0.73, "m", "Confirmada"),
    ("porta_h", "Altura das portas (padrão)", 2.10, "m", "Estimada"),
    ("faixa", "Faixa de entrada (parede leste)", 0.86, "m", "Confirmada"),
    ("porta_ent_l", "Porta de entrada c/ batente", 0.80, "m", "Confirmada"),
    ("parede_d_comp", "Parede D — comprimento", 2.65, "m", "Confirmada"),
    ("teto_faixa_l", "Faixa de entrada — comprimento", 1.95, "m", "Calculada"),
    ("area_e", "Área Parede E (− janela)", "=parede_e_comp*pe_direito-janela_l*janela_h", "m²", "Calculada"),
    ("area_c", "Área Parede C", "=parede_c_comp*pe_direito", "m²", "Calculada"),
    ("area_bwc", "Área parede do banheiro (+ acima da porta)", "=bwc_trechos*pe_direito+porta_bwc_l*(pe_direito-porta_h)", "m²", "Calculada"),
    ("area_leste", "Área parede leste (− porta)", "=faixa*pe_direito-porta_ent_l*porta_h", "m²", "Calculada"),
    ("area_paredes", "TOTAL paredes grafite", "=area_e+area_c+area_bwc+area_leste", "m²", "Calculada"),
    ("area_teto", "Área do teto", "=parede_d_comp*parede_e_comp+teto_faixa_l*faixa", "m²", "Calculada"),
    ("area_pintura_total", "Área total de pintura (paredes + teto)", "=area_paredes+area_teto", "m²", "Calculada"),
    ("area_ripado", "Área do ripado (Parede D inteira)", "=parede_d_comp*pe_direito", "m²", "Calculada"),
    ("demaos_parede", "Demãos nas paredes (cor escura sobre clara)", 3, "un", "Premissa"),
    ("demaos_teto", "Demãos no teto", 2, "un", "Premissa"),
    ("perda_tinta", "Perda de tinta", 0.10, "%", "Premissa"),
    ("rend_galao", "Rendimento por galão 3,6 L por demão (conservador; conferir embalagem)", 40, "m²", "Estimada"),
    ("galoes_parede", "Galões para paredes", "=ROUNDUP(area_paredes*demaos_parede*(1+perda_tinta)/rend_galao,0)", "galão", "Calculada"),
    ("galoes_teto", "Galões para teto", "=ROUNDUP(area_teto*demaos_teto*(1+perda_tinta)/rend_galao,0)", "galão", "Calculada"),
    ("led_prateleira", "LED sob a prateleira", 1.70, "m", "Projeto"),
    ("led_vertical", "LED vertical no ripado (por perfil)", 2.40, "m", "Projeto"),
    ("led_nichos", "LED dos 3 nichos (3 × 0,24)", 0.72, "m", "Projeto"),
    ("n_verticais", "Nº de perfis verticais (Econômico/Equilibrado)", 1, "un", "Projeto"),
    ("perda_led", "Sobra de corte da fita", 0.10, "%", "Premissa"),
    ("metros_led", "Metros de fita LED", "=(led_prateleira+led_vertical*n_verticais+led_nichos)*(1+perda_led)", "m", "Calculada"),
    ("rolos_led", "Rolos de 5 m", "=ROUNDUP(metros_led/5,0)", "rolo", "Calculada"),
    ("barras_perfil", "Barras de perfil de 2 m", "=ROUNDUP(led_prateleira/2,0)+n_verticais*ROUNDUP(led_vertical/2,0)", "barra", "Calculada"),
    ("n_verticais_prem", "Nº de perfis verticais — Premium", 2, "un", "Projeto"),
    ("metros_led_prem", "Metros de fita LED — Premium", "=(led_prateleira+led_vertical*n_verticais_prem+led_nichos)*(1+perda_led)", "m", "Calculada"),
    ("rolos_led_prem", "Rolos de 5 m — Premium", "=ROUNDUP(metros_led_prem/5,0)", "rolo", "Calculada"),
    ("barras_perfil_prem", "Barras de perfil de 2 m — Premium", "=ROUNDUP(led_prateleira/2,0)+n_verticais_prem*ROUNDUP(led_vertical/2,0)", "barra", "Calculada"),
    ("contingencia", "Reserva para imprevistos", 0.10, "%", "Premissa"),
]
